﻿using Microsoft.AspNetCore.Mvc;

namespace StockManagementProject.Controllers
{
    public class SupplierController : Controller
    {
        public IActionResult ViewSupplier()
        {
            return View();
        }
    }
}
