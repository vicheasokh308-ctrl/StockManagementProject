﻿namespace StockManagementProject.Models
{
    public class ClsUserManagement
    {
       
        public string? First_Name { get; set; }
        public string? Last_Name { get; set; }
        public string? Role { get; set; }
        public string? Description { get; set; }

        public string? Email { get; set; }
        public string? Password { get; set; }
        public string? change {  get; set; }
        public DateTime Date {  get; set; }
        public string? status { get; set; }
        public string? image { get; set; }
    }
}
