﻿namespace StockManagementProject.Models
{
    public class ClsSpplier
    {
        public string? Supplier_Name {  get; set; }
        public string? Address { get; set; }
        public string ? Sex { get; set; }
        public string? Status { get; set; }
    }
}
