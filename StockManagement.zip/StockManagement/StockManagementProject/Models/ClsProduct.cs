﻿namespace StockManagementProject.Models
{
    public class ClsProduct
    {
        public string? Product_Name {  get; set; }
        public int Unit {  get; set; }
        public int Cost_Price { get; set; }
        public string? Status { get; set; }
        public string? image {  get; set; }
    }
}
