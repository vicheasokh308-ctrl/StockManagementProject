﻿namespace StockManagementProject.Models
{
    public class ClsWarehouse
    {
        public string? Warehouse_Name { get; set; }
        public string? Location { get; set; }
        public string? status { get; set; }
    }
}
