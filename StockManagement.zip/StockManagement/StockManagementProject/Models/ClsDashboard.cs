﻿namespace StockManagementProject.Models
{
    public class ClsDashboard
    {
    }
}
