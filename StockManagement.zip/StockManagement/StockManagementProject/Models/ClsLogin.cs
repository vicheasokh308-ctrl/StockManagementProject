﻿namespace StockManagementProject.Models
{
    public class ClsLogin
    {
        public string? Email { get; set; }
        public string? Password { get; set; }
        public string? status { get; set; }
    }
}
